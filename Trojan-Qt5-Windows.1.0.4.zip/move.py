import shutil

shutil.move("../../3rd/trojan-qt5-core/trojan-qt5-core.dll", "trojan-qt5-core.dll")
