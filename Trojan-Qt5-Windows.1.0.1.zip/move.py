import shutil

shutil.move("../../3rd/trojan-qt5-libs/trojan-qt5-libs.dll", "trojan-qt5-libs.dll")